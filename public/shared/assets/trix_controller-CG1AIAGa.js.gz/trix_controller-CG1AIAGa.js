import{C as e}from"./application-BzDBbQCT.js";class l extends e{connect(){document.getElementById(this.element.id)}}export{l as default};
//# sourceMappingURL=trix_controller-CG1AIAGa.js.map
