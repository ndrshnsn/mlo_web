import{F as r}from"./fetch_request-Bi6ZTe2Y.js";async function n(e,t){return new r("post",e,t).perform()}export{n as p};
//# sourceMappingURL=verbs-DNA89zgE.js.map
