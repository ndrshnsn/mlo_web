import{C as e}from"./application-BzDBbQCT.js";class r extends e{clear_state(){sessionStorage.setItem("clearDTState",!0)}}export{r as default};
//# sourceMappingURL=managedt_controller-B6LiJpxr.js.map
