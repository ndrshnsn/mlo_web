import{C as t}from"./application-BzDBbQCT.js";class s extends t{connect(){$(this.element).toast("show")}}export{s as default};
//# sourceMappingURL=toast_controller-COwlaahM.js.map
