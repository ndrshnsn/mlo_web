import{l as c}from"./application-BzDBbQCT.js";const a={t(t){const e=document.querySelector("body").getAttribute("data-locale");return t.split(".").reduce((r,o)=>r[o],c[e])}};export{a as i};
//# sourceMappingURL=i18n-CTZ1ofMK.js.map
