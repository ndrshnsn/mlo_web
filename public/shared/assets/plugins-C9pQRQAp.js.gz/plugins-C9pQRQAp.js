document.querySelectorAll("form .auth-pass-inputgroup").forEach(function(t){t.querySelectorAll(".password-addon").forEach(function(o){o.addEventListener("click",function(r){var e=t.querySelector(".password-input");e.type==="password"?e.type="text":e.type="password"})})});
//# sourceMappingURL=plugins-C9pQRQAp.js.map
