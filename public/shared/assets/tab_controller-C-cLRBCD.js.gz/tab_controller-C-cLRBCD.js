import{C as a}from"./application-BzDBbQCT.js";class o extends a{toggle(){let t=this.element,l=t.closest("ul").getElementsByTagName("a");for(var e=0;e<l.length;e++)l[e].classList.remove("active");t.classList.add("active")}}export{o as default};
//# sourceMappingURL=tab_controller-C-cLRBCD.js.map
